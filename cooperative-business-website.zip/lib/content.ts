import { createClient } from '@/lib/supabase/server'

export type Service = {
  id: string
  title: string
  description: string
  icon: string
  sort_order: number
  is_visible: boolean
}

export type ContactMessage = {
  id: string
  name: string
  phone: string
  message: string
  is_read: boolean
  created_at: string
}

export type SiteContent = Record<string, string>

const FALLBACK: SiteContent = {
  hero_headline: 'Growing Together Through Cooperation & Online Trade',
  hero_intro:
    'OBED-EMMA Online Cooperative is a Ghana-based cooperative business that empowers members through group buying, online marketplaces, shared savings, loans, and skills development.',
  about_body:
    'OBED-EMMA Online Cooperative operates as a cooperative model where members pool resources, share costs, and split profits fairly. Members participate in planning, operations, and decision-making to ensure transparency and collective growth.',
  membership_who:
    'Membership is open to traders, farmers, artisans, and entrepreneurs across the Ashanti Region and beyond who believe in the power of working together.',
  membership_benefits:
    'Access bulk-buying discounts, sell your goods on our online marketplace, borrow from a shared fund to grow your business, build savings with the group, and gain practical business, financial, and digital skills.',
  contact_phone: '050 133 1649',
  contact_intro:
    'Have a question or want to join? Reach out to us by phone or send a message and our team will get back to you.',
}

export async function getSiteContent(): Promise<SiteContent> {
  const supabase = await createClient()
  const { data } = await supabase.from('site_content').select('key, value')
  const map: SiteContent = { ...FALLBACK }
  for (const row of data ?? []) {
    map[row.key] = row.value
  }
  return map
}

export async function getServices(adminView = false): Promise<Service[]> {
  const supabase = await createClient()
  let query = supabase
    .from('services')
    .select('*')
    .order('sort_order', { ascending: true })
  if (!adminView) {
    query = query.eq('is_visible', true)
  }
  const { data } = await query
  return (data as Service[]) ?? []
}
