import Link from 'next/link'
import { ShieldX } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function ForbiddenPage() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center bg-sidebar px-4 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
        <ShieldX className="h-7 w-7" aria-hidden="true" />
      </span>
      <h1 className="mt-4 text-2xl font-bold text-foreground">Access denied</h1>
      <p className="mt-2 max-w-sm text-muted-foreground">
        You do not have permission to view this page. Only cooperative
        administrators can access the dashboard.
      </p>
      <Button asChild className="mt-6">
        <Link href="/">Back to website</Link>
      </Button>
    </div>
  )
}
