import Link from 'next/link'
import { FileText, Boxes, MessageSquare, MailOpen, ArrowRight } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/server'

export default async function AdminOverviewPage() {
  const supabase = await createClient()

  const [{ count: serviceCount }, { count: messageCount }, { count: unreadCount }] =
    await Promise.all([
      supabase.from('services').select('*', { count: 'exact', head: true }),
      supabase.from('contact_messages').select('*', { count: 'exact', head: true }),
      supabase
        .from('contact_messages')
        .select('*', { count: 'exact', head: true })
        .eq('is_read', false),
    ])

  const stats = [
    {
      label: 'Services',
      value: serviceCount ?? 0,
      icon: Boxes,
      href: '/admin/services',
    },
    {
      label: 'Total messages',
      value: messageCount ?? 0,
      icon: MessageSquare,
      href: '/admin/messages',
    },
    {
      label: 'Unread messages',
      value: unreadCount ?? 0,
      icon: MailOpen,
      href: '/admin/messages',
    },
  ]

  const quickLinks = [
    {
      title: 'Edit website content',
      body: 'Update the hero, about, membership and contact text shown to visitors.',
      href: '/admin/content',
      icon: FileText,
    },
    {
      title: 'Manage services',
      body: 'Add, edit, hide, or remove the service cards on your site.',
      href: '/admin/services',
      icon: Boxes,
    },
    {
      title: 'View messages',
      body: 'Read and manage enquiries submitted through the contact form.',
      href: '/admin/messages',
      icon: MessageSquare,
    },
  ]

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-2xl font-bold tracking-tight text-foreground">
        Dashboard
      </h1>
      <p className="mt-1 text-muted-foreground">
        Manage your cooperative website content and member enquiries.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {stats.map((stat) => (
          <Link key={stat.label} href={stat.href}>
            <Card className="border-border transition-colors hover:border-primary">
              <CardContent className="flex items-center justify-between p-5">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="mt-1 text-3xl font-bold text-foreground">
                    {stat.value}
                  </p>
                </div>
                <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary">
                  <stat.icon className="h-6 w-6" aria-hidden="true" />
                </span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <h2 className="mt-10 text-lg font-semibold text-foreground">
        Quick actions
      </h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {quickLinks.map((link) => (
          <Link key={link.href} href={link.href}>
            <Card className="h-full border-border transition-colors hover:border-primary">
              <CardContent className="flex h-full flex-col p-5">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-primary">
                  <link.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="mt-3 font-semibold text-foreground">
                  {link.title}
                </h3>
                <p className="mt-1 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {link.body}
                </p>
                <span className="mt-3 inline-flex items-center text-sm font-medium text-primary">
                  Open
                  <ArrowRight className="ml-1 h-4 w-4" />
                </span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="mt-10 rounded-xl border border-dashed border-border bg-card p-6">
        <h2 className="font-semibold text-foreground">Coming soon</h2>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
          Future expansion is reserved for admins only: e-commerce product
          uploads, member-only dashboards, Mobile Money payments, and a
          marketplace activation toggle.
        </p>
      </div>
    </div>
  )
}
