import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { AdminShell } from '@/components/admin/admin-shell'

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Defense in depth: middleware also guards these routes.
  if (!user) redirect('/auth/login')
  if (user.user_metadata?.is_admin !== true) redirect('/auth/forbidden')

  const { count } = await supabase
    .from('contact_messages')
    .select('*', { count: 'exact', head: true })
    .eq('is_read', false)

  return (
    <AdminShell email={user.email ?? ''} unreadCount={count ?? 0}>
      {children}
    </AdminShell>
  )
}
