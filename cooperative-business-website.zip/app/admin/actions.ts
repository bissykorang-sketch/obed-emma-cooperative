'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

async function requireAdmin() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user || user.user_metadata?.is_admin !== true) {
    throw new Error('Unauthorized')
  }
  return supabase
}

function revalidatePublic() {
  revalidatePath('/', 'layout')
}

export type ActionState = { ok: boolean; message: string }

export async function updateSiteContent(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await requireAdmin()

  const entries = Array.from(formData.entries()).filter(([key]) =>
    key.startsWith('content_'),
  )

  for (const [field, value] of entries) {
    const key = field.replace('content_', '')
    const { error } = await supabase
      .from('site_content')
      .upsert(
        { key, value: String(value), updated_at: new Date().toISOString() },
        { onConflict: 'key' },
      )
    if (error) {
      return { ok: false, message: `Failed to save: ${error.message}` }
    }
  }

  revalidatePublic()
  return { ok: true, message: 'Website content updated successfully.' }
}

export async function createService(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await requireAdmin()
  const title = String(formData.get('title') ?? '').trim()
  const description = String(formData.get('description') ?? '').trim()
  const icon = String(formData.get('icon') ?? 'package')
  const sort_order = Number(formData.get('sort_order') ?? 0)

  if (!title || !description) {
    return { ok: false, message: 'Title and description are required.' }
  }

  const { error } = await supabase
    .from('services')
    .insert({ title, description, icon, sort_order })

  if (error) return { ok: false, message: error.message }

  revalidatePublic()
  revalidatePath('/admin/services')
  return { ok: true, message: 'Service added.' }
}

export async function updateService(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await requireAdmin()
  const id = String(formData.get('id') ?? '')
  const title = String(formData.get('title') ?? '').trim()
  const description = String(formData.get('description') ?? '').trim()
  const icon = String(formData.get('icon') ?? 'package')
  const sort_order = Number(formData.get('sort_order') ?? 0)
  const is_visible = formData.get('is_visible') === 'on'

  if (!id || !title || !description) {
    return { ok: false, message: 'Title and description are required.' }
  }

  const { error } = await supabase
    .from('services')
    .update({ title, description, icon, sort_order, is_visible })
    .eq('id', id)

  if (error) return { ok: false, message: error.message }

  revalidatePublic()
  revalidatePath('/admin/services')
  return { ok: true, message: 'Service updated.' }
}

export async function deleteService(formData: FormData) {
  const supabase = await requireAdmin()
  const id = String(formData.get('id') ?? '')
  if (id) {
    await supabase.from('services').delete().eq('id', id)
    revalidatePublic()
    revalidatePath('/admin/services')
  }
}

export async function toggleServiceVisibility(formData: FormData) {
  const supabase = await requireAdmin()
  const id = String(formData.get('id') ?? '')
  const next = formData.get('next') === 'true'
  if (id) {
    await supabase.from('services').update({ is_visible: next }).eq('id', id)
    revalidatePublic()
    revalidatePath('/admin/services')
  }
}

export async function setMessageRead(formData: FormData) {
  const supabase = await requireAdmin()
  const id = String(formData.get('id') ?? '')
  const next = formData.get('next') === 'true'
  if (id) {
    await supabase
      .from('contact_messages')
      .update({ is_read: next })
      .eq('id', id)
    revalidatePath('/admin/messages')
    revalidatePath('/admin')
  }
}

export async function deleteMessage(formData: FormData) {
  const supabase = await requireAdmin()
  const id = String(formData.get('id') ?? '')
  if (id) {
    await supabase.from('contact_messages').delete().eq('id', id)
    revalidatePath('/admin/messages')
    revalidatePath('/admin')
  }
}

export async function signOutAction() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  redirect('/auth/login')
}
