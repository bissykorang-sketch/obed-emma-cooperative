import { ServicesManager } from '@/components/admin/services-manager'
import { getServices } from '@/lib/content'

export default async function AdminServicesPage() {
  const services = await getServices(true)

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-bold tracking-tight text-foreground">
        Services
      </h1>
      <p className="mt-1 text-muted-foreground">
        Add, edit, hide, or remove the service cards shown on your website.
      </p>
      <div className="mt-8">
        <ServicesManager services={services} />
      </div>
    </div>
  )
}
