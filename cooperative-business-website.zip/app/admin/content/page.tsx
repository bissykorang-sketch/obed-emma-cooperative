import { ContentForm } from '@/components/admin/content-form'
import { getSiteContent } from '@/lib/content'

export default async function AdminContentPage() {
  const content = await getSiteContent()

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-bold tracking-tight text-foreground">
        Site Content
      </h1>
      <p className="mt-1 text-muted-foreground">
        Edit the text shown to visitors across your website. Changes are saved
        instantly.
      </p>
      <div className="mt-8">
        <ContentForm content={content} />
      </div>
    </div>
  )
}
