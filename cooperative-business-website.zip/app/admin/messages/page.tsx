import { MessagesList } from '@/components/admin/messages-list'
import { createClient } from '@/lib/supabase/server'
import type { ContactMessage } from '@/lib/content'

export default async function AdminMessagesPage() {
  const supabase = await createClient()
  const { data } = await supabase
    .from('contact_messages')
    .select('*')
    .order('created_at', { ascending: false })

  const messages = (data as ContactMessage[]) ?? []

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-bold tracking-tight text-foreground">
        Contact Messages
      </h1>
      <p className="mt-1 text-muted-foreground">
        Enquiries submitted by visitors through the contact form.
      </p>
      <div className="mt-8">
        <MessagesList messages={messages} />
      </div>
    </div>
  )
}
