import type { Metadata } from 'next'
import Link from 'next/link'
import {
  ArrowRight,
  Sprout,
  Store,
  Scissors,
  Briefcase,
  CheckCircle2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getSiteContent } from '@/lib/content'

export const metadata: Metadata = {
  title: 'Membership',
  description:
    'Find out who can join OBED-EMMA Online Cooperative, the benefits of membership, and the simple steps to become a member in Ghana.',
}

const WHO_CAN_JOIN = [
  { icon: Sprout, label: 'Farmers & producers' },
  { icon: Store, label: 'Traders & shop owners' },
  { icon: Scissors, label: 'Artisans & crafters' },
  { icon: Briefcase, label: 'Entrepreneurs' },
]

const BENEFITS = [
  'Bulk-buying discounts on food and goods',
  'Sell your produce, clothing and crafts on our marketplace',
  'Borrow from a shared fund to grow your business',
  'Build savings together with the group',
  'Business, financial, and digital skills training',
  'A voice in cooperative decisions',
]

const STEPS = [
  {
    title: 'Reach out',
    body: 'Contact us by phone or through the contact form to express your interest.',
  },
  {
    title: 'Complete registration',
    body: 'Provide your details and agree to the simple cooperative membership terms.',
  },
  {
    title: 'Start participating',
    body: 'Begin saving, buying, selling, and benefiting alongside other members.',
  },
]

export default async function MembershipPage() {
  const content = await getSiteContent()

  return (
    <>
      <section className="bg-sidebar">
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground">
            Become a Member
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Join a growing community of Ghanaians building wealth through
            cooperation and online trade.
          </p>
          <Button asChild size="lg" className="mt-6">
            <Link href="/contact">
              Become a Member
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-12 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-foreground">
              Who can join
            </h2>
            <p className="mt-3 leading-relaxed text-muted-foreground">
              {content.membership_who}
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {WHO_CAN_JOIN.map((item) => (
                <div
                  key={item.label}
                  className="flex items-center gap-3 rounded-lg border border-border bg-card p-3"
                >
                  <item.icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  <span className="text-sm font-medium text-foreground">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold tracking-tight text-foreground">
              Membership benefits
            </h2>
            <p className="mt-3 leading-relaxed text-muted-foreground">
              {content.membership_benefits}
            </p>
            <ul className="mt-6 flex flex-col gap-3">
              {BENEFITS.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3">
                  <CheckCircle2
                    className="mt-0.5 h-5 w-5 shrink-0 text-primary"
                    aria-hidden="true"
                  />
                  <span className="text-sm leading-relaxed text-foreground">
                    {benefit}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-sidebar">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-center text-3xl font-bold tracking-tight text-foreground">
            Simple steps to join
          </h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {STEPS.map((step, i) => (
              <div
                key={step.title}
                className="rounded-xl border border-border bg-card p-6"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
                  {i + 1}
                </span>
                <h3 className="mt-4 font-semibold text-foreground">
                  {step.title}
                </h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {step.body}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Button asChild size="lg">
              <Link href="/contact">
                Start your application
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
