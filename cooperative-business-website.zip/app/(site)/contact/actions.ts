'use server'

import { createClient } from '@/lib/supabase/server'

export type ContactState = {
  ok: boolean
  message: string
}

export async function submitContactMessage(
  _prev: ContactState,
  formData: FormData,
): Promise<ContactState> {
  const name = String(formData.get('name') ?? '').trim()
  const phone = String(formData.get('phone') ?? '').trim()
  const message = String(formData.get('message') ?? '').trim()

  if (!name || !phone || !message) {
    return { ok: false, message: 'Please fill in all fields.' }
  }
  if (name.length > 120 || phone.length > 40 || message.length > 2000) {
    return { ok: false, message: 'One or more fields are too long.' }
  }

  const supabase = await createClient()
  const { error } = await supabase
    .from('contact_messages')
    .insert({ name, phone, message })

  if (error) {
    console.log('[v0] contact insert error:', error.message)
    return {
      ok: false,
      message: 'Something went wrong. Please try again or call us.',
    }
  }

  return {
    ok: true,
    message: 'Thank you! Your message has been sent. We will be in touch soon.',
  }
}
