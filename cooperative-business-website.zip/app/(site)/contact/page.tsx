import type { Metadata } from 'next'
import { Phone, MapPin, ExternalLink } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ContactForm } from '@/components/contact-form'
import { getSiteContent } from '@/lib/content'

export const metadata: Metadata = {
  title: 'Contact Us',
  description:
    'Contact OBED-EMMA Online Cooperative in the Ashanti Region, Ghana. Call 050 133 1649 or send us a message.',
}

const MAPS_QUERY = encodeURIComponent(
  'OBED-EMMA Online Cooperative, Ashanti Region, Ghana',
)
const MAPS_LINK = 'https://maps.app.goo.gl/g33x7r1SoL2Y1hNc7'

export default async function ContactPage() {
  const content = await getSiteContent()
  const phone = content.contact_phone

  return (
    <>
      <section className="bg-sidebar">
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground">
            Contact Us
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            {content.contact_intro}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-10 md:grid-cols-2">
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-4">
              <a
                href={`tel:${phone.replace(/\s/g, '')}`}
                className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary">
                  <Phone className="h-5 w-5" aria-hidden="true" />
                </span>
                <span>
                  <span className="block text-sm text-muted-foreground">
                    Call us
                  </span>
                  <span className="block font-semibold text-foreground">
                    {phone}
                  </span>
                </span>
              </a>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary">
                  <MapPin className="h-5 w-5" aria-hidden="true" />
                </span>
                <span>
                  <span className="block text-sm text-muted-foreground">
                    Location
                  </span>
                  <span className="block font-semibold text-foreground">
                    Ashanti Region, Ghana
                  </span>
                </span>
              </div>
            </div>

            <div className="overflow-hidden rounded-xl border border-border">
              <iframe
                title="Map showing OBED-EMMA Online Cooperative location"
                src={`https://www.google.com/maps?q=${MAPS_QUERY}&output=embed`}
                className="h-64 w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
              <div className="border-t border-border bg-card p-3">
                <Button asChild variant="outline" size="sm" className="w-full">
                  <a href={MAPS_LINK} target="_blank" rel="noopener noreferrer">
                    View on Google Maps
                    <ExternalLink className="ml-1 h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>

          <Card className="border-border">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold text-foreground">
                Send us a message
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Fill in the form and our team will get back to you.
              </p>
              <div className="mt-6">
                <ContactForm />
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </>
  )
}
