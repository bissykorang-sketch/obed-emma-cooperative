import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ServiceIcon } from '@/components/service-icon'
import { getServices } from '@/lib/content'

export const metadata: Metadata = {
  title: 'Services',
  description:
    'Group buying, online marketplace, savings & loans, and skills training from OBED-EMMA Online Cooperative in Ghana.',
}

export default async function ServicesPage() {
  const services = await getServices()

  return (
    <>
      <section className="bg-sidebar">
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground">
            Our Services
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Everything our members need to buy smarter, sell wider, save
            together, and build new skills.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-6 sm:grid-cols-2">
          {services.map((service) => (
            <Card key={service.id} className="border-border">
              <CardContent className="flex gap-4 p-6">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
                  <ServiceIcon name={service.icon} className="h-6 w-6" />
                </span>
                <div>
                  <h2 className="text-lg font-semibold text-foreground">
                    {service.title}
                  </h2>
                  <p className="mt-1 leading-relaxed text-muted-foreground">
                    {service.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-border bg-sidebar p-8 text-center">
          <h2 className="text-balance text-2xl font-bold tracking-tight text-foreground">
            Want to benefit from these services?
          </h2>
          <p className="mx-auto mt-2 max-w-xl text-pretty text-muted-foreground">
            Join OBED-EMMA Online Cooperative and start trading, saving, and
            growing with the community.
          </p>
          <Button asChild className="mt-6">
            <Link href="/membership">
              Become a Member
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  )
}
