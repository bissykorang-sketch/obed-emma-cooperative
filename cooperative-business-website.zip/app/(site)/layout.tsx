import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { getSiteContent } from '@/lib/content'

export default async function SiteLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const content = await getSiteContent()
  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter phone={content.contact_phone} />
    </div>
  )
}
