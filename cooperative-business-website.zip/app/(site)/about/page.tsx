import type { Metadata } from 'next'
import Image from 'next/image'
import { Users, Scale, Handshake, Eye } from 'lucide-react'
import { getSiteContent } from '@/lib/content'

export const metadata: Metadata = {
  title: 'About Us',
  description:
    'Learn how OBED-EMMA Online Cooperative pools resources, shares costs, and splits profits fairly with members across the Ashanti Region, Ghana.',
}

const PRINCIPLES = [
  {
    icon: Users,
    title: 'Member Owned',
    body: 'Every member has a voice. The cooperative belongs to the people it serves.',
  },
  {
    icon: Scale,
    title: 'Fair Profit Sharing',
    body: 'Costs and profits are split fairly among members based on participation.',
  },
  {
    icon: Handshake,
    title: 'Shared Resources',
    body: 'Members pool funds and buying power to unlock bigger opportunities.',
  },
  {
    icon: Eye,
    title: 'Full Transparency',
    body: 'Members take part in planning, operations and decision-making.',
  },
]

export default async function AboutPage() {
  const content = await getSiteContent()

  return (
    <>
      <section className="bg-sidebar">
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground">
            About OBED-EMMA Online Cooperative
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            {content.about_body}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border shadow-sm">
            <Image
              src="/images/cooperative-meeting.png"
              alt="Cooperative members meeting to plan and make decisions together"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
          <div className="flex flex-col gap-4">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground">
              A cooperative built on trust
            </h2>
            <p className="leading-relaxed text-muted-foreground">
              We operate as a cooperative model where members pool resources,
              share costs, and split profits fairly. By working together, our
              members achieve more than they could alone — accessing lower
              prices, new markets, shared savings, and affordable loans.
            </p>
            <p className="leading-relaxed text-muted-foreground">
              Members participate in planning, operations, and decision-making,
              ensuring the cooperative stays transparent and accountable to the
              community it serves.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-sidebar">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-center text-3xl font-bold tracking-tight text-foreground">
            Our Cooperative Principles
          </h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {PRINCIPLES.map((p) => (
              <div
                key={p.title}
                className="rounded-xl border border-border bg-card p-6"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary">
                  <p.icon className="h-6 w-6" aria-hidden="true" />
                </span>
                <h3 className="mt-4 font-semibold text-foreground">{p.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {p.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
