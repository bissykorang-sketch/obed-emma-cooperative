import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ServiceIcon } from '@/components/service-icon'
import { getSiteContent, getServices } from '@/lib/content'

export default async function HomePage() {
  const [content, services] = await Promise.all([
    getSiteContent(),
    getServices(),
  ])

  return (
    <>
      {/* Hero */}
      <section className="bg-sidebar">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div className="flex flex-col gap-6">
            <span className="inline-flex w-fit items-center rounded-full bg-secondary px-3 py-1 text-xs font-medium text-primary">
              Ashanti Region, Ghana
            </span>
            <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl">
              {content.hero_headline}
            </h1>
            <p className="text-pretty text-lg leading-relaxed text-muted-foreground">
              {content.hero_intro}
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg">
                <Link href="/membership">
                  Join the Cooperative
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border shadow-sm">
            <Image
              src="/images/cooperative-hero.png"
              alt="OBED-EMMA cooperative members working together at a market in the Ashanti Region"
              fill
              priority
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
        </div>
      </section>

      {/* Intro values */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-6 sm:grid-cols-3">
          {[
            {
              title: 'Pool Resources',
              body: 'Members combine their buying power to access better prices and bigger opportunities.',
            },
            {
              title: 'Share Profits Fairly',
              body: 'Costs and profits are split fairly so everyone grows together.',
            },
            {
              title: 'Decide Together',
              body: 'Members take part in planning and decisions for full transparency.',
            },
          ].map((item) => (
            <div key={item.title} className="flex gap-3">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
              <div>
                <h3 className="font-semibold text-foreground">{item.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {item.body}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Services preview */}
      <section className="bg-sidebar">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground">
              What We Offer
            </h2>
            <p className="mt-3 text-pretty text-muted-foreground">
              Practical services designed to help our members earn more, save
              more, and grow their businesses.
            </p>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service) => (
              <Card key={service.id} className="h-full border-border">
                <CardContent className="flex flex-col gap-3 p-6">
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary">
                    <ServiceIcon name={service.icon} className="h-6 w-6" />
                  </span>
                  <h3 className="font-semibold text-foreground">
                    {service.title}
                  </h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Button asChild variant="outline">
              <Link href="/services">
                Explore all services
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="rounded-2xl bg-primary px-6 py-12 text-center text-primary-foreground md:py-16">
          <h2 className="text-balance text-3xl font-bold tracking-tight">
            Ready to grow together?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-pretty text-primary-foreground/90">
            Become a member of OBED-EMMA Online Cooperative and join a community
            building wealth through cooperation and online trade.
          </p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" variant="secondary">
              <Link href="/membership">Become a Member</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
