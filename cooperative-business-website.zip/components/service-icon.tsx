import {
  ShoppingCart,
  Store,
  PiggyBank,
  GraduationCap,
  Package,
  HandCoins,
  Users,
  Sprout,
  type LucideIcon,
} from 'lucide-react'

const ICONS: Record<string, LucideIcon> = {
  'shopping-cart': ShoppingCart,
  store: Store,
  'piggy-bank': PiggyBank,
  'graduation-cap': GraduationCap,
  package: Package,
  'hand-coins': HandCoins,
  users: Users,
  sprout: Sprout,
}

export const ICON_OPTIONS = Object.keys(ICONS)

export function ServiceIcon({
  name,
  className,
}: {
  name: string
  className?: string
}) {
  const Icon = ICONS[name] ?? Package
  return <Icon className={className} aria-hidden="true" />
}
