'use client'

import { Phone, Trash2, MailOpen, Mail } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { setMessageRead, deleteMessage } from '@/app/admin/actions'
import type { ContactMessage } from '@/lib/content'

function formatDate(value: string) {
  return new Date(value).toLocaleString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function MessagesList({ messages }: { messages: ContactMessage[] }) {
  if (messages.length === 0) {
    return (
      <Card className="border-border">
        <CardContent className="p-10 text-center text-muted-foreground">
          No messages yet. Enquiries from the contact form will appear here.
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      {messages.map((msg) => (
        <Card
          key={msg.id}
          className={msg.is_read ? 'border-border' : 'border-primary/40 bg-primary/[0.03]'}
        >
          <CardContent className="p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-foreground">{msg.name}</h3>
                  {!msg.is_read && <Badge>New</Badge>}
                </div>
                <a
                  href={`tel:${msg.phone.replace(/\s/g, '')}`}
                  className="mt-1 inline-flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  <Phone className="h-3.5 w-3.5" />
                  {msg.phone}
                </a>
              </div>
              <span className="text-xs text-muted-foreground">
                {formatDate(msg.created_at)}
              </span>
            </div>

            <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-foreground">
              {msg.message}
            </p>

            <div className="mt-4 flex gap-2">
              <form action={setMessageRead}>
                <input type="hidden" name="id" value={msg.id} />
                <input type="hidden" name="next" value={(!msg.is_read).toString()} />
                <Button type="submit" variant="outline" size="sm">
                  {msg.is_read ? (
                    <>
                      <Mail className="mr-1 h-3.5 w-3.5" />
                      Mark unread
                    </>
                  ) : (
                    <>
                      <MailOpen className="mr-1 h-3.5 w-3.5" />
                      Mark read
                    </>
                  )}
                </Button>
              </form>
              <form
                action={deleteMessage}
                onSubmit={(e) => {
                  if (!confirm('Delete this message?')) e.preventDefault()
                }}
              >
                <input type="hidden" name="id" value={msg.id} />
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="mr-1 h-3.5 w-3.5" />
                  Delete
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
