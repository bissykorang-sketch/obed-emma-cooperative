'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard,
  FileText,
  Boxes,
  MessageSquare,
  LogOut,
  ExternalLink,
  Menu,
  X,
  Sprout,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { signOutAction } from '@/app/admin/actions'

const NAV = [
  { href: '/admin', label: 'Overview', icon: LayoutDashboard },
  { href: '/admin/content', label: 'Site Content', icon: FileText },
  { href: '/admin/services', label: 'Services', icon: Boxes },
  { href: '/admin/messages', label: 'Messages', icon: MessageSquare },
]

export function AdminShell({
  email,
  unreadCount,
  children,
}: {
  email: string
  unreadCount: number
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const navList = (
    <nav className="flex flex-col gap-1">
      {NAV.map((item) => {
        const active =
          item.href === '/admin'
            ? pathname === '/admin'
            : pathname.startsWith(item.href)
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={() => setOpen(false)}
            className={cn(
              'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
              active
                ? 'bg-secondary text-primary'
                : 'text-muted-foreground hover:bg-secondary/60 hover:text-foreground',
            )}
          >
            <item.icon className="h-4 w-4" aria-hidden="true" />
            {item.label}
            {item.href === '/admin/messages' && unreadCount > 0 && (
              <span className="ml-auto rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">
                {unreadCount}
              </span>
            )}
          </Link>
        )
      })}
    </nav>
  )

  return (
    <div className="flex min-h-svh bg-sidebar">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-border bg-card p-4 md:flex">
        <Link href="/admin" className="mb-6 flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Sprout className="h-5 w-5" aria-hidden="true" />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-sm font-bold text-foreground">Admin</span>
            <span className="text-xs text-muted-foreground">OBED-EMMA</span>
          </span>
        </Link>
        {navList}
        <div className="mt-auto flex flex-col gap-2 pt-4">
          <Button asChild variant="outline" size="sm">
            <Link href="/" target="_blank">
              View site
              <ExternalLink className="ml-1 h-4 w-4" />
            </Link>
          </Button>
          <form action={signOutAction}>
            <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground">
              <LogOut className="mr-2 h-4 w-4" />
              Sign out
            </Button>
          </form>
          <p className="truncate px-2 text-xs text-muted-foreground">{email}</p>
        </div>
      </aside>

      <div className="flex flex-1 flex-col">
        {/* Mobile top bar */}
        <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 md:hidden">
          <span className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sprout className="h-4 w-4" aria-hidden="true" />
            </span>
            <span className="text-sm font-bold text-foreground">Admin</span>
          </span>
          <button
            type="button"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="rounded-md p-2 text-foreground"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </header>

        {open && (
          <div className="border-b border-border bg-card p-4 md:hidden">
            {navList}
            <div className="mt-4 flex flex-col gap-2">
              <Button asChild variant="outline" size="sm">
                <Link href="/" target="_blank">
                  View site
                  <ExternalLink className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <form action={signOutAction}>
                <Button variant="ghost" size="sm" className="w-full justify-start">
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </Button>
              </form>
            </div>
          </div>
        )}

        <main className="flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  )
}
