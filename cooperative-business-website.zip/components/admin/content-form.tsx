'use client'

import { useActionState, useEffect } from 'react'
import { useFormStatus } from 'react-dom'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { updateSiteContent, type ActionState } from '@/app/admin/actions'
import type { SiteContent } from '@/lib/content'

const initialState: ActionState = { ok: false, message: '' }

type Field = {
  key: keyof SiteContent & string
  label: string
  help: string
  multiline?: boolean
}

const SECTIONS: { title: string; fields: Field[] }[] = [
  {
    title: 'Home – Hero',
    fields: [
      { key: 'hero_headline', label: 'Hero headline', help: 'Main headline on the home page.' },
      { key: 'hero_intro', label: 'Hero intro text', help: 'Short paragraph under the headline.', multiline: true },
    ],
  },
  {
    title: 'About',
    fields: [
      { key: 'about_body', label: 'About text', help: 'Description shown on the About page.', multiline: true },
    ],
  },
  {
    title: 'Membership',
    fields: [
      { key: 'membership_who', label: 'Who can join', help: 'Explains who is eligible to join.', multiline: true },
      { key: 'membership_benefits', label: 'Membership benefits', help: 'Summary of benefits.', multiline: true },
    ],
  },
  {
    title: 'Contact',
    fields: [
      { key: 'contact_phone', label: 'Phone number', help: 'Displayed across the site and footer.' },
      { key: 'contact_intro', label: 'Contact intro text', help: 'Short intro on the Contact page.', multiline: true },
    ],
  },
]

function SaveButton() {
  const { pending } = useFormStatus()
  return (
    <Button type="submit" disabled={pending}>
      {pending ? 'Saving...' : 'Save changes'}
    </Button>
  )
}

export function ContentForm({ content }: { content: SiteContent }) {
  const [state, formAction] = useActionState(updateSiteContent, initialState)

  useEffect(() => {
    if (!state.message) return
    if (state.ok) toast.success(state.message)
    else toast.error(state.message)
  }, [state])

  return (
    <form action={formAction} className="flex flex-col gap-6">
      {SECTIONS.map((section) => (
        <Card key={section.title} className="border-border">
          <CardContent className="flex flex-col gap-4 p-6">
            <h2 className="font-semibold text-foreground">{section.title}</h2>
            {section.fields.map((field) => (
              <div key={field.key} className="flex flex-col gap-2">
                <Label htmlFor={field.key}>{field.label}</Label>
                {field.multiline ? (
                  <Textarea
                    id={field.key}
                    name={`content_${field.key}`}
                    defaultValue={content[field.key] ?? ''}
                    rows={4}
                  />
                ) : (
                  <Input
                    id={field.key}
                    name={`content_${field.key}`}
                    defaultValue={content[field.key] ?? ''}
                  />
                )}
                <p className="text-xs text-muted-foreground">{field.help}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
      <div className="sticky bottom-4 flex justify-end">
        <SaveButton />
      </div>
    </form>
  )
}
