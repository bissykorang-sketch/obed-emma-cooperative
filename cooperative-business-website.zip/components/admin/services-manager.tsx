'use client'

import { useActionState, useEffect, useState } from 'react'
import { useFormStatus } from 'react-dom'
import { toast } from 'sonner'
import { Eye, EyeOff, Trash2, Plus, Pencil } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  createService,
  updateService,
  deleteService,
  toggleServiceVisibility,
  type ActionState,
} from '@/app/admin/actions'
import { ServiceIcon, ICON_OPTIONS } from '@/components/service-icon'
import type { Service } from '@/lib/content'

const initialState: ActionState = { ok: false, message: '' }

function IconSelect({ name, defaultValue }: { name: string; defaultValue?: string }) {
  return (
    <select
      name={name}
      defaultValue={defaultValue ?? 'package'}
      className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground"
    >
      {ICON_OPTIONS.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  )
}

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus()
  return (
    <Button type="submit" size="sm" disabled={pending}>
      {pending ? 'Saving...' : label}
    </Button>
  )
}

function AddServiceForm() {
  const [state, formAction] = useActionState(createService, initialState)
  useEffect(() => {
    if (!state.message) return
    state.ok ? toast.success(state.message) : toast.error(state.message)
  }, [state])

  return (
    <Card className="border-border">
      <CardContent className="p-6">
        <h2 className="flex items-center gap-2 font-semibold text-foreground">
          <Plus className="h-4 w-4 text-primary" />
          Add a new service
        </h2>
        <form action={formAction} className="mt-4 flex flex-col gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-2">
              <Label htmlFor="new-title">Title</Label>
              <Input id="new-title" name="title" required placeholder="Service title" />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="new-icon">Icon</Label>
              <IconSelect name="icon" />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="new-desc">Description</Label>
            <Textarea id="new-desc" name="description" required rows={2} />
          </div>
          <div className="flex items-end gap-4">
            <div className="flex w-28 flex-col gap-2">
              <Label htmlFor="new-order">Order</Label>
              <Input id="new-order" name="sort_order" type="number" defaultValue={0} />
            </div>
            <SubmitButton label="Add service" />
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

function EditServiceCard({ service }: { service: Service }) {
  const [editing, setEditing] = useState(false)
  const [state, formAction] = useActionState(updateService, initialState)

  useEffect(() => {
    if (!state.message) return
    if (state.ok) {
      toast.success(state.message)
      setEditing(false)
    } else {
      toast.error(state.message)
    }
  }, [state])

  return (
    <Card className="border-border">
      <CardContent className="p-5">
        {!editing ? (
          <div className="flex items-start gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
              <ServiceIcon name={service.icon} className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground">{service.title}</h3>
                {service.is_visible ? (
                  <Badge variant="secondary">Visible</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Hidden
                  </Badge>
                )}
              </div>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Order: {service.sort_order}
              </p>
            </div>
            <div className="flex shrink-0 flex-col gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditing(true)}
              >
                <Pencil className="h-3.5 w-3.5" />
                <span className="sr-only sm:not-sr-only sm:ml-1">Edit</span>
              </Button>
              <form action={toggleServiceVisibility}>
                <input type="hidden" name="id" value={service.id} />
                <input
                  type="hidden"
                  name="next"
                  value={(!service.is_visible).toString()}
                />
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  title={service.is_visible ? 'Hide from site' : 'Show on site'}
                >
                  {service.is_visible ? (
                    <EyeOff className="h-3.5 w-3.5" />
                  ) : (
                    <Eye className="h-3.5 w-3.5" />
                  )}
                </Button>
              </form>
              <form
                action={deleteService}
                onSubmit={(e) => {
                  if (!confirm('Delete this service?')) e.preventDefault()
                }}
              >
                <input type="hidden" name="id" value={service.id} />
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  className="w-full text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </form>
            </div>
          </div>
        ) : (
          <form action={formAction} className="flex flex-col gap-4">
            <input type="hidden" name="id" value={service.id} />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex flex-col gap-2">
                <Label htmlFor={`title-${service.id}`}>Title</Label>
                <Input
                  id={`title-${service.id}`}
                  name="title"
                  defaultValue={service.title}
                  required
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor={`icon-${service.id}`}>Icon</Label>
                <IconSelect name="icon" defaultValue={service.icon} />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor={`desc-${service.id}`}>Description</Label>
              <Textarea
                id={`desc-${service.id}`}
                name="description"
                defaultValue={service.description}
                rows={2}
                required
              />
            </div>
            <div className="flex flex-wrap items-end gap-4">
              <div className="flex w-28 flex-col gap-2">
                <Label htmlFor={`order-${service.id}`}>Order</Label>
                <Input
                  id={`order-${service.id}`}
                  name="sort_order"
                  type="number"
                  defaultValue={service.sort_order}
                />
              </div>
              <label className="flex items-center gap-2 text-sm text-foreground">
                <input
                  type="checkbox"
                  name="is_visible"
                  defaultChecked={service.is_visible}
                  className="h-4 w-4 accent-primary"
                />
                Visible on site
              </label>
            </div>
            <div className="flex gap-2">
              <SubmitButton label="Save" />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setEditing(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  )
}

export function ServicesManager({ services }: { services: Service[] }) {
  return (
    <div className="flex flex-col gap-6">
      <AddServiceForm />
      <div className="flex flex-col gap-4">
        {services.length === 0 ? (
          <p className="text-sm text-muted-foreground">No services yet.</p>
        ) : (
          services.map((service) => (
            <EditServiceCard key={service.id} service={service} />
          ))
        )}
      </div>
    </div>
  )
}
