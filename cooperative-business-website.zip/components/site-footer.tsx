import Link from 'next/link'
import { Sprout, Phone, MapPin } from 'lucide-react'

export function SiteFooter({ phone = '050 133 1649' }: { phone?: string }) {
  return (
    <footer className="border-t border-border bg-sidebar">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sprout className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="text-base font-bold text-foreground">
              OBED-EMMA Online Cooperative
            </span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            A Ghana-based cooperative empowering members through group buying,
            online trade, savings & loans, and skills development.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-foreground">Explore</h3>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted-foreground">
            <li>
              <Link href="/about" className="hover:text-primary">
                About Us
              </Link>
            </li>
            <li>
              <Link href="/services" className="hover:text-primary">
                Services
              </Link>
            </li>
            <li>
              <Link href="/membership" className="hover:text-primary">
                Membership
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-primary">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-foreground">Get in touch</h3>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-primary" aria-hidden="true" />
              <a href={`tel:${phone.replace(/\s/g, '')}`} className="hover:text-primary">
                {phone}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" aria-hidden="true" />
              Ashanti Region, Ghana
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
          <p>
            &copy; {new Date().getFullYear()} OBED-EMMA Online Cooperative. All
            rights reserved.
          </p>
          <Link href="/auth/login" className="hover:text-primary">
            Admin Login
          </Link>
        </div>
      </div>
    </footer>
  )
}
